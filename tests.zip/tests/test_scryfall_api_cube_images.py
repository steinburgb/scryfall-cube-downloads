"""
Tests for scryfall_api_cube_images.py using a real CubeCobra export
(tests/data/SimpleTwobertTest.csv: 180 single-faced cards, no duplicates).
The offline tests depend on that exact row count and order, so edit a copy
rather than the file itself when experimenting.

The tests run offline. Scryfall is replaced by FakeScryfall, which answers
/cards/collection from the CSV itself and serves a small unique "image" for
every card URL. The fake can be told to rate-limit, drop, or lose cards so
the error paths are exercised too.

Run with either:
    python -m unittest discover -s tests -v
    pytest tests -v

Set SCRYFALL_LIVE=1 to also run one small end-to-end download against the
real API (needs network, fetches the first 5 cards of the CSV).
"""

import csv
import hashlib
import io
import json
import os
import shutil
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import requests
from PIL import Image

# Make the script importable when tests run from the repo root or tests/.
REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO_ROOT))

import scryfall_api_cube_images as dl  # noqa: E402

DATA_CSV = Path(__file__).parent / "data" / "SimpleTwobertTest.csv"
PNG_MAGIC = b"\x89PNG\r\n\x1a\n"


# --- Fake Scryfall -------------------------------------------------------------

class FakeResponse:
    """Minimal stand-in for requests.Response covering what the script uses."""

    def __init__(self, status=200, body=b"", headers=None):
        self.status_code = status
        self._body = body
        self.headers = headers or {}

    def raise_for_status(self):
        if self.status_code >= 400:
            raise requests.HTTPError(f"HTTP {self.status_code}")

    def json(self):
        return json.loads(self._body)

    def iter_content(self, size):
        for i in range(0, len(self._body), size):
            yield self._body[i:i + size]

    def close(self):
        pass


class FakeScryfall:
    """
    Answers the two kinds of request the script makes:
      POST /cards/collection  -> card JSON built from the CSV rows
      GET  <image url>        -> a small fake PNG unique to that URL
    """

    def __init__(self, csv_path):
        self.cards = {}
        with open(csv_path, newline="", encoding="utf-8-sig") as f:
            for row in csv.DictReader(f):
                key = (row["Set"].lower(), row["Collector Number"])
                self.cards[key] = row["name"]
        self.collection_calls = []      # list of identifier lists, one per POST
        self.image_calls = []           # list of image URLs requested
        self.missing = set()            # keys Scryfall should report as not_found
        self.rate_limit_once = set()    # image URLs that get one 429 first
        self.fail_always = set()        # image URLs that always 500
        self.double_faced = set()       # keys to present as two-faced cards
        self.related = {}               # key -> list of all_parts entries (see add_token)
        self.tokens = {}                # scryfall id -> token card JSON

    @staticmethod
    def image_url(set_code, num, face="front"):
        return f"https://cards.scryfall.io/png/{face}/{set_code}/{num}.png"

    _image_cache = {}

    @classmethod
    def image_bytes(cls, url):
        # A real (tiny) PNG in a colour derived from the URL, so every card's
        # bytes and checksum differ and the sheet assembler can open them.
        if url not in cls._image_cache:
            h = hashlib.sha256(url.encode()).digest()
            img = Image.new("RGB", (15, 21), (h[0], h[1], h[2]))
            buf = io.BytesIO()
            img.save(buf, "PNG")
            cls._image_cache[url] = buf.getvalue()
        return cls._image_cache[url]

    def add_token(self, creator_key, token_id, name, oracle_id, component="token",
                  type_line="Token Creature", set_code="tfake", num=None):
        """Register a related part on a cube card and the token card it points to."""
        num = num or token_id.rsplit("-", 1)[-1]
        self.related.setdefault(creator_key, []).append(
            {"object": "related_card", "id": token_id, "component": component,
             "name": name, "type_line": type_line})
        self.tokens[token_id] = {
            "id": token_id, "oracle_id": oracle_id, "name": name,
            "set": set_code, "collector_number": num, "type_line": type_line,
            "image_uris": {"png": self.image_url(set_code, num)},
        }

    def card_json(self, key):
        set_code, num = key
        card = {
            "id": f"fake-{set_code}-{num}",
            "name": self.cards[key],
            "set": set_code,
            "collector_number": num,
        }
        if key in self.related:
            # Scryfall lists the card itself among its parts too.
            card["all_parts"] = [{"object": "related_card", "id": card["id"],
                                  "component": "combo_piece", "name": card["name"],
                                  "type_line": "Creature"}] + self.related[key]
        if key in self.double_faced:
            card["card_faces"] = [
                {"image_uris": {"png": self.image_url(set_code, num, "front")}},
                {"image_uris": {"png": self.image_url(set_code, num, "back")}},
            ]
        else:
            card["image_uris"] = {"png": self.image_url(set_code, num)}
        return card

    def request(self, method, url, **kwargs):
        if url == dl.SCRYFALL_COLLECTION_URL:
            idents = kwargs["json"]["identifiers"]
            self.collection_calls.append(idents)
            found, not_found = [], []
            for ident in idents:
                if "id" in ident:                      # token lookup by Scryfall ID
                    if ident["id"] in self.tokens:
                        found.append(self.tokens[ident["id"]])
                    else:
                        not_found.append(ident)
                    continue
                key = (ident["set"], ident["collector_number"])
                if key in self.cards and key not in self.missing:
                    found.append(self.card_json(key))
                else:
                    not_found.append(ident)
            body = json.dumps({"data": found, "not_found": not_found}).encode()
            return FakeResponse(200, body)

        # Image download
        self.image_calls.append(url)
        if url in self.fail_always:
            return FakeResponse(500)
        if url in self.rate_limit_once:
            self.rate_limit_once.discard(url)
            return FakeResponse(429, headers={"Retry-After": "0"})
        return FakeResponse(200, self.image_bytes(url))


# --- Test base -----------------------------------------------------------------

class DownloaderTestCase(unittest.TestCase):
    """Shared setup: temp output folder, fake Scryfall, no delays or backoff."""

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="scryfall-test-"))
        self.out = self.tmp / "out"
        self.fake = FakeScryfall(DATA_CSV)
        patches = [
            mock.patch.object(requests.Session, "request", autospec=True,
                              side_effect=lambda self_, m, u, **kw: self.fake.request(m, u, **kw)),
            mock.patch.object(dl.time, "sleep", lambda s: None),   # keep tests fast
        ]
        for p in patches:
            p.start()
            self.addCleanup(p.stop)

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def run_script(self, *extra):
        argv = [str(DATA_CSV), "--out", str(self.out), "--delay", "0", *extra]
        with mock.patch("sys.stdout"):          # silence progress output
            return dl.main(argv)

    def manifest_rows(self):
        with open(self.out / "manifest.csv", newline="", encoding="utf-8") as f:
            return list(csv.DictReader(f))

    def read_sheet_csv(self, name):
        with open(self.out / "cardsheets" / name, newline="", encoding="utf-8") as f:
            return list(csv.DictReader(f))

    def read_index(self):
        return {r["sheet"]: r for r in self.read_sheet_csv("sheets.csv")}


# --- CSV parsing ---------------------------------------------------------------

class TestReadCubeCsv(unittest.TestCase):

    def setUp(self):
        self.rows = dl.read_cube_csv(DATA_CSV)

    def test_reads_every_row(self):
        self.assertEqual(len(self.rows), 180)

    def test_set_codes_are_lowercased(self):
        self.assertTrue(all(r["set"] == r["set"].lower() for r in self.rows))

    def test_hyphenated_collector_numbers_survive(self):
        # The List (plst) uses numbers like "DMR-271"; these must be kept verbatim.
        plst = {r["collector_number"] for r in self.rows if r["set"] == "plst"}
        self.assertIn("DMR-271", plst)
        self.assertIn("ORI-213", plst)

    def test_empty_color_falls_back_to_unknown(self):
        # Colourless cards (artifacts, lands) have an empty Color cell in CubeCobra exports.
        unknown = [r for r in self.rows if r["color"] == "Unknown"]
        self.assertEqual(len(unknown), 30)
        self.assertIn(("cmr", "458"), {(r["set"], r["collector_number"]) for r in unknown})  # Bonesplitter

    def test_color_and_rarity_values(self):
        by_key = {(r["set"], r["collector_number"]): r for r in self.rows}
        self.assertEqual(by_key[("ogw", "159")]["color"], "RU")       # Stormchaser Mage
        self.assertEqual(by_key[("dmr", "151")]["rarity"], "rare")     # Birds of Paradise

    def test_no_rows_are_tagged_double_sided(self):
        self.assertFalse(any(r["tagged_double_sided"] for r in self.rows))

    def test_alternate_column_names(self):
        rows = dl.read_cube_csv(DATA_CSV, color_column="Color Category")
        # This export has "null" in every Color Category cell; the script keeps it verbatim.
        self.assertEqual({r["color"] for r in rows}, {"null"})

    def test_copies_defaults_to_one_without_column(self):
        self.assertTrue(all(r["copies"] == 1 for r in self.rows))

    def test_copies_column(self):
        tmp = Path(tempfile.mkdtemp(prefix="scryfall-copies-"))
        self.addCleanup(shutil.rmtree, tmp, True)
        copy = tmp / "copies.csv"
        with open(copy, "w", newline="", encoding="utf-8") as f:
            f.write("Set,Collector Number,copies\n")
            f.write("inr,186,3\n")      # three copies
            f.write("fdn,227,\n")       # blank -> 1
            f.write("dmr,151,0\n")      # invalid -> 1 with a warning
            f.write("j25,662,two\n")    # invalid -> 1 with a warning
        with mock.patch("sys.stdout"):
            rows = dl.read_cube_csv(copy)
        self.assertEqual([r["copies"] for r in rows], [3, 1, 1, 1])

    def test_skip_maybeboard(self):
        # Flip two rows to maybeboard=true in a temp copy and check they drop out.
        tmp = Path(tempfile.mkdtemp(prefix="scryfall-maybe-"))
        self.addCleanup(shutil.rmtree, tmp, True)
        copy = tmp / "maybe.csv"
        with open(DATA_CSV, newline="", encoding="utf-8-sig") as src, \
                open(copy, "w", newline="", encoding="utf-8") as dst:
            reader = csv.DictReader(src)
            writer = csv.DictWriter(dst, fieldnames=reader.fieldnames)
            writer.writeheader()
            for row in reader:
                if row["name"] in ("Ambush Viper", "Serra Angel"):
                    row["maybeboard"] = "true"
                writer.writerow(row)
        with mock.patch("sys.stdout"):
            kept = dl.read_cube_csv(copy, skip_maybeboard=True)
            default = dl.read_cube_csv(copy)
        self.assertEqual(len(default), 180, "maybeboard rows are kept unless the flag is given")
        self.assertEqual(len(kept), 178)
        keys = {(r["set"], r["collector_number"]) for r in kept}
        self.assertNotIn(("inr", "186"), keys)
        self.assertNotIn(("plst", "DMR-271"), keys)

    def test_missing_column_name_gives_unknown(self):
        rows = dl.read_cube_csv(DATA_CSV, color_column="No Such Column")
        self.assertEqual({r["color"] for r in rows}, {"Unknown"})


# --- Scryfall lookup -----------------------------------------------------------

class TestLookup(DownloaderTestCase):

    def test_batches_of_75(self):
        rows = dl.read_cube_csv(DATA_CSV)
        found, not_found = dl.lookup_cards(requests.Session(), rows, delay=0)
        sizes = [len(b) for b in self.fake.collection_calls]
        self.assertEqual(sizes, [75, 75, 30])
        self.assertEqual(len(found), 180)
        self.assertEqual(not_found, [])

    def test_identifiers_are_exact(self):
        rows = dl.read_cube_csv(DATA_CSV)
        dl.lookup_cards(requests.Session(), rows, delay=0)
        sent = [(i["set"], i["collector_number"]) for b in self.fake.collection_calls for i in b]
        self.assertIn(("plst", "DMR-271"), sent)
        self.assertIn(("sld", "2318"), sent)

    def test_duplicates_are_looked_up_once(self):
        rows = dl.read_cube_csv(DATA_CSV)
        rows = rows + rows[:5]        # pretend five cards appear twice
        dl.lookup_cards(requests.Session(), rows, delay=0)
        self.assertEqual(sum(len(b) for b in self.fake.collection_calls), 180)

    def test_card_faces_single_and_double(self):
        self.assertEqual(dl.card_faces({"image_uris": {"png": "u"}}), [("front", "u")])
        dfc = {"card_faces": [{"image_uris": {"png": "f"}}, {"image_uris": {"png": "b"}}]}
        self.assertEqual(dl.card_faces(dfc), [("front", "f"), ("back", "b")])
        # Split/adventure cards have card_faces without image_uris and a top-level image.
        split = {"image_uris": {"png": "s"}, "card_faces": [{"name": "a"}, {"name": "b"}]}
        self.assertEqual(dl.card_faces(split), [("front", "s")])


# --- Colour mode ---------------------------------------------------------------

class TestColourMode(DownloaderTestCase):

    def test_downloads_every_card_into_colour_folders(self):
        self.assertEqual(self.run_script(), 0)
        files = sorted(p for p in self.out.rglob("*.png"))
        self.assertEqual(len(files), 180)

        folders = {p.parent.name for p in files}
        self.assertEqual(folders, {"W", "U", "B", "R", "G", "Unknown",
                                   "RU", "BW", "BG", "GU", "GW", "GR", "RW", "BR", "UW", "BU"})
        self.assertEqual(len(list((self.out / "Unknown").glob("*.png"))), 30)
        self.assertTrue((self.out / "W" / "plst_DMR-271.png").exists())      # Serra Angel
        self.assertTrue((self.out / "RU" / "ogw_159.png").exists())          # Stormchaser Mage

    def test_files_are_real_downloads(self):
        self.run_script()
        f = self.out / "G" / "inr_186.png"                                   # Ambush Viper
        expected = self.fake.image_bytes(self.fake.image_url("inr", "186"))
        self.assertEqual(f.read_bytes(), expected)
        self.assertFalse(list(self.out.rglob("*.part")), "no temp files left behind")

    def test_manifest_matches_files(self):
        self.run_script()
        rows = self.manifest_rows()
        self.assertEqual(len(rows), 180)
        self.assertEqual(set(rows[0].keys()), set(dl.MANIFEST_FIELDS))
        for row in rows:
            path = self.out / row["file"]
            self.assertTrue(path.exists(), row["file"])
            self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(), row["sha256"])
            self.assertEqual(row["face"], "front")
            self.assertTrue(row["scryfall_id"].startswith("fake-"))
        names = {r["name"] for r in rows}
        self.assertIn("Lightning Bolt", names)
        self.assertIn("Appa, Aang's Companion", names)

    def test_rerun_skips_existing_and_does_not_grow_manifest(self):
        self.run_script()
        first_images = len(self.fake.image_calls)
        self.assertEqual(self.run_script(), 0)
        self.assertEqual(len(self.fake.image_calls), first_images, "nothing re-downloaded")
        self.assertEqual(len(self.manifest_rows()), 180)

    def test_force_redownloads(self):
        self.run_script()
        first_images = len(self.fake.image_calls)
        self.run_script("--force")
        self.assertEqual(len(self.fake.image_calls), first_images * 2)


# --- Rarity mode ---------------------------------------------------------------

class TestRarityMode(DownloaderTestCase):

    def test_rarity_then_colour_layout(self):
        self.assertEqual(self.run_script("--mode", "rarity"), 0)
        self.assertTrue((self.out / "rare" / "G" / "dmr_151.png").exists())        # Birds of Paradise
        self.assertTrue((self.out / "common" / "Unknown" / "cmr_458.png").exists())  # Bonesplitter
        self.assertTrue((self.out / "uncommon" / "W" / "plst_DMR-271.png").exists())
        self.assertEqual(len(list(self.out.rglob("*.png"))), 180)
        self.assertEqual({p.name for p in self.out.iterdir() if p.is_dir()},
                         {"common", "uncommon", "rare"})


# --- Sheets mode ---------------------------------------------------------------

class TestSheetsMode(DownloaderTestCase):

    def test_69_card_batches_with_card_back(self):
        self.assertEqual(self.run_script("--mode", "sheets"), 0)
        folders = sorted(p.name for p in self.out.iterdir() if p.is_dir())
        self.assertEqual(folders, ["Sheet_fronts_1", "Sheet_fronts_2", "Sheet_fronts_3"])
        counts = [len(dl.sheet_slots(self.out / f)) for f in folders]
        self.assertEqual(counts, [69, 69, 42])          # 180 = 69 + 69 + 42
        for f in folders:
            back = self.out / f / dl.CARD_BACK_NAME
            self.assertTrue(back.exists(), f"{f} is missing the card back")
            self.assertEqual(back.read_bytes()[:8], PNG_MAGIC)
        # No double-faced cards in this cube, so no back-face folders.
        self.assertFalse(any(n.startswith("Sheet_backs") for n in folders))

    def test_batches_follow_csv_order(self):
        self.run_script("--mode", "sheets")
        self.assertTrue((self.out / "Sheet_fronts_1" / "01 inr_186.png").exists())    # row 1
        self.assertTrue((self.out / "Sheet_fronts_1" / "69 2x2_59.png").exists())     # row 69 (Mistfire Adept)
        self.assertTrue((self.out / "Sheet_fronts_2" / "01 inr_76.png").exists())     # row 70 (Mist Raven)
        self.assertTrue((self.out / "Sheet_fronts_3" / "42 inr_273.png").exists())    # row 180

    def test_custom_sheet_size(self):
        self.run_script("--mode", "sheets", "--sheet-size", "50")
        folders = sorted(p.name for p in self.out.iterdir() if p.is_dir())
        self.assertEqual(folders, ["Sheet_fronts_1", "Sheet_fronts_2", "Sheet_fronts_3", "Sheet_fronts_4"])
        self.assertEqual(len(dl.sheet_slots(self.out / "Sheet_fronts_4")), 30)

    def test_rerun_keeps_layout_stable(self):
        self.run_script("--mode", "sheets")
        before = sorted(str(p.relative_to(self.out)) for p in self.out.rglob("*.png"))
        self.run_script("--mode", "sheets")
        after = sorted(str(p.relative_to(self.out)) for p in self.out.rglob("*.png"))
        self.assertEqual(before, after)

    def test_no_card_back_flag(self):
        self.run_script("--mode", "sheets", "--no-card-back")
        self.assertFalse(list(self.out.rglob(dl.CARD_BACK_NAME)))

    def test_double_faced_card_gets_back_folder(self):
        # Pretend Serra Angel is double-faced to exercise the backs path with this CSV.
        self.fake.double_faced.add(("plst", "DMR-271"))
        self.assertEqual(self.run_script("--mode", "sheets"), 0)
        self.assertTrue((self.out / "Sheet_fronts_1" / "07 plst_DMR-271.png").exists())   # row 7
        self.assertTrue((self.out / "Sheet_backs_1" / "01 plst_DMR-271_back.png").exists())
        self.assertTrue((self.out / "Sheet_backs_1" / dl.CARD_BACK_NAME).exists())
        faces = [r["face"] for r in self.manifest_rows() if r["set"] == "plst" and r["collector_number"] == "DMR-271"]
        self.assertEqual(sorted(faces), ["back", "front"])

    def test_failed_download_does_not_consume_a_slot(self):
        # Kill row 1's image; the other 68 cards of sheet 1 plus row 70 should fill it to 69.
        self.fake.fail_always.add(self.fake.image_url("inr", "186"))
        self.assertEqual(self.run_script("--mode", "sheets"), 1)
        self.assertEqual(len(dl.sheet_slots(self.out / "Sheet_fronts_1")), 69)
        self.assertTrue((self.out / "Sheet_fronts_1" / "01 fdn_227.png").exists())    # row 2 took slot 1
        self.assertTrue((self.out / "Sheet_fronts_1" / "69 inr_76.png").exists())     # row 70 moved up
        self.assertEqual(sum(len(dl.sheet_slots(p)) for p in self.out.iterdir() if p.is_dir()), 179)


# --- Sheet assembly ------------------------------------------------------------

class TestAssemble(DownloaderTestCase):

    def test_grid_for(self):
        self.assertEqual(dl.grid_for(70, "auto"), (10, 7))     # full sheet
        self.assertEqual(dl.grid_for(43, "auto"), (7, 7))      # 42 cards + back
        self.assertEqual(dl.grid_for(2, "auto"), (2, 1))
        self.assertEqual(dl.grid_for(50, "auto"), (8, 7))      # sqrt(50)=7.07 -> 8 cols, 7 rows
        self.assertEqual(dl.grid_for(5, (10, 7)), (10, 7))     # fixed grid is used as given

    def test_assemble_after_download(self):
        self.assertEqual(self.run_script("--mode", "sheets", "--assemble"), 0)
        sheets = sorted(p.name for p in (self.out / "cardsheets").iterdir())
        self.assertEqual(sheets, ["Sheet_fronts_1.csv", "Sheet_fronts_1.png",
                                  "Sheet_fronts_2.csv", "Sheet_fronts_2.png",
                                  "Sheet_fronts_3.csv", "Sheet_fronts_3.png", "sheets.csv"])
        # Default tile is 488 wide -> 681 tall (745:1040 ratio).
        # Full sheets: 69 cards + back = 70 tiles = 10x7.
        with Image.open(self.out / "cardsheets" / "Sheet_fronts_1.png") as im:
            self.assertEqual(im.size, (4880, 4767))
        # Last sheet: 42 cards + back = 43 tiles -> 7x7 auto grid.
        with Image.open(self.out / "cardsheets" / "Sheet_fronts_3.png") as im:
            self.assertEqual(im.size, (7 * 488, 7 * 681))

    def test_native_tile_width(self):
        self.run_script("--mode", "sheets", "--assemble", "--tile-width", "745")
        with Image.open(self.out / "cardsheets" / "Sheet_fronts_1.png") as im:
            self.assertEqual(im.size, (7450, 7280))

    def test_sheet_csv_describes_slots(self):
        self.run_script("--mode", "sheets", "--assemble", "--tile-width", "15")
        rows = self.read_sheet_csv("Sheet_fronts_1.csv")
        self.assertEqual(list(rows[0].keys()), dl.SHEET_FIELDS)
        self.assertEqual(len(rows), 70)                       # 69 cards + card back
        first, last, back = rows[0], rows[68], rows[69]
        self.assertEqual((first["slot"], first["column"], first["row"]), ("1", "1", "1"))
        self.assertEqual((first["name"], first["set"], first["collector_number"], first["face"]),
                         ("Ambush Viper", "inr", "186", "front"))
        self.assertEqual((last["slot"], last["column"], last["row"], last["name"]),
                         ("69", "9", "7", "Mistfire Adept"))
        self.assertEqual((back["slot"], back["column"], back["row"], back["name"], back["file"]),
                         ("70", "10", "7", "Card back", dl.CARD_BACK_NAME))
        # Sheet-level columns repeat on every row.
        self.assertTrue(all(r["columns"] == "10" and r["rows"] == "7" and
                            r["tile_width"] == "15" and r["tile_height"] == "21" and
                            r["sheet_width"] == "150" and r["sheet_height"] == "147"
                            for r in rows))
        self.assertTrue(all(r["scryfall_id"].startswith("fake-") for r in rows[:69]))
        rows3 = self.read_sheet_csv("Sheet_fronts_3.csv")
        self.assertEqual(len(rows3), 43)
        self.assertEqual((rows3[41]["slot"], rows3[41]["name"]), ("42", "Traveler's Amulet"))
        self.assertEqual((rows3[42]["slot"], rows3[42]["name"]), ("49", "Card back"))

    def test_sheet_index_csv(self):
        self.run_script("--mode", "sheets", "--assemble", "--tile-width", "15")
        index = self.read_index()
        self.assertEqual(list(index), ["Sheet_fronts_1.png", "Sheet_fronts_2.png", "Sheet_fronts_3.png"])
        s1, s3 = index["Sheet_fronts_1.png"], index["Sheet_fronts_3.png"]
        self.assertEqual((s1["columns"], s1["rows"], s1["cards"], s1["back_slot"]), ("10", "7", "69", "70"))
        self.assertEqual((s3["columns"], s3["rows"], s3["cards"], s3["back_slot"]), ("7", "7", "42", "49"))
        self.assertEqual((s3["sheet_width"], s3["sheet_height"], s3["manifest"]),
                         ("105", "147", "Sheet_fronts_3.csv"))

    def test_tiles_land_in_the_right_place(self):
        self.run_script("--mode", "sheets", "--assemble", "--tile-width", "15")
        # Tile 15x21 matches the fake images exactly, so pixels are copied unscaled.
        with Image.open(self.out / "cardsheets" / "Sheet_fronts_1.png") as im:
            self.assertEqual(im.size, (150, 147))
            expected = Image.open(io.BytesIO(self.fake.image_bytes(self.fake.image_url("inr", "186"))))
            self.assertEqual(im.getpixel((0, 0))[:3], expected.getpixel((0, 0)))          # slot 1
            eleven = Image.open(io.BytesIO(self.fake.image_bytes(self.fake.image_url("dmr", "151"))))
            self.assertEqual(im.getpixel((2 * 15 + 1, 0))[:3], eleven.getpixel((0, 0)))    # slot 3 = row 3
            self.assertGreater(im.getpixel((9 * 15 + 7, 6 * 21 + 10))[3], 0)                # back in slot 70
        with Image.open(self.out / "cardsheets" / "Sheet_fronts_3.png") as im:
            # 43 tiles in 7x7: slots 44-48 are empty (transparent), 49 holds the back.
            self.assertEqual(im.getpixel((1 * 15 + 7, 6 * 21 + 10))[3], 0)
            self.assertGreater(im.getpixel((6 * 15 + 7, 6 * 21 + 10))[3], 0)

    def test_fixed_grid(self):
        self.run_script("--mode", "sheets", "--assemble", "--grid", "10x7", "--tile-width", "15")
        for name in ("Sheet_fronts_1.png", "Sheet_fronts_3.png"):
            with Image.open(self.out / "cardsheets" / name) as im:
                self.assertEqual(im.size, (150, 147))
        self.assertEqual(self.read_index()["Sheet_fronts_3.png"]["back_slot"], "70")

    def test_assemble_only_rebuilds_without_downloading(self):
        self.run_script("--mode", "sheets")
        calls = len(self.fake.image_calls)
        self.assertEqual(self.run_script("--mode", "sheets", "--assemble-only", "--tile-width", "15"), 0)
        self.assertEqual(len(self.fake.image_calls), calls)
        self.assertTrue((self.out / "cardsheets" / "Sheet_fronts_2.png").exists())
        # Names still resolve because manifest.csv from the first run is read back.
        self.assertEqual(self.read_sheet_csv("Sheet_fronts_2.csv")[0]["name"], "Mist Raven")

    def test_assemble_includes_back_sheets(self):
        self.fake.double_faced.add(("plst", "DMR-271"))
        self.run_script("--mode", "sheets", "--assemble", "--tile-width", "15")
        b = self.read_index()["Sheet_backs_1.png"]
        self.assertEqual((b["columns"], b["rows"], b["cards"], b["back_slot"]), ("2", "1", "1", "2"))
        self.assertEqual(self.read_sheet_csv("Sheet_backs_1.csv")[0]["face"], "back")

    def test_assemble_requires_sheets_mode(self):
        with mock.patch("sys.stderr"):
            with self.assertRaises(SystemExit):
                dl.parse_args([str(DATA_CSV), "--assemble"])
            with self.assertRaises(SystemExit):
                dl.parse_args([str(DATA_CSV), "--mode", "sheets", "--grid", "11x7"])
            with self.assertRaises(SystemExit):
                dl.parse_args([str(DATA_CSV), "--mode", "sheets", "--sheet-size", "70"])


# --- Tokens and copies ---------------------------------------------------------

class TestTokens(DownloaderTestCase):

    def setUp(self):
        super().setUp()
        f = self.fake
        # Two cards make the same Spider token (same oracle_id, different printings).
        f.add_token(("mh1", "212"), "tok-spider-a", "Spider", "oracle-spider", set_code="tmh1", num="8")
        f.add_token(("dsk", "180"), "tok-spider-b", "Spider", "oracle-spider", set_code="tdsk", num="12")
        # A Treasure token, an emblem, and a meld result.
        f.add_token(("woe", "212"), "tok-treasure", "Treasure", "oracle-treasure",
                    type_line="Token Artifact — Treasure", set_code="twoe", num="19")
        f.add_token(("sld", "2318"), "emb-arena", "Phyrexian Arena Emblem", "oracle-emblem",
                    component="combo_piece", type_line="Emblem — Phyrexian Arena", set_code="tsld", num="1")
        f.add_token(("bro", "14"), "meld-titan", "Urza, Planeswalker", "oracle-meld",
                    component="meld_result", type_line="Legendary Planeswalker", set_code="bro", num="238a")
        # A dungeon (linked as a combo piece, like emblems).
        f.add_token(("cmm", "264"), "dun-undercity", "Undercity", "oracle-undercity",
                    component="combo_piece", type_line="Dungeon", set_code="tclb", num="21")
        # Things that must NOT be fetched: a plain combo piece and a meld partner.
        f.related[("bro", "14")].append({"object": "related_card", "id": "combo-x",
                                          "component": "combo_piece", "name": "Other Card",
                                          "type_line": "Artifact"})
        f.related[("bro", "14")].append({"object": "related_card", "id": "meld-part-x",
                                          "component": "meld_part", "name": "Mishra",
                                          "type_line": "Legendary Creature"})

    def test_related_token_ids_filters_and_orders(self):
        rows = dl.read_cube_csv(DATA_CSV)
        cards, _ = dl.lookup_cards(requests.Session(), rows, delay=0)
        ordered = [cards[(r["set"], r["collector_number"])] for r in rows]
        wanted = dl.related_token_ids(ordered)
        # Cube order: Ruby (woe 212, row 25) before Rotwidow Pack (mh1 212, row 31) ...
        self.assertEqual(list(wanted), ["tok-treasure", "tok-spider-a", "meld-titan",
                                        "dun-undercity", "emb-arena", "tok-spider-b"])
        self.assertEqual(wanted["tok-spider-a"], ["Rotwidow Pack"])
        self.assertNotIn("combo-x", wanted)
        self.assertNotIn("meld-part-x", wanted)

    def test_tokens_are_deduplicated_by_oracle_id(self):
        self.assertEqual(self.run_script("--mode", "sheets", "--tokens", "--assemble", "--tile-width", "15"), 0)
        folder = self.out / "Sheet_tokens_1"
        names = [p.name for _, p in dl.sheet_slots(folder)]
        self.assertEqual(names, ["01 twoe_19.png", "02 tmh1_8.png", "03 bro_238a.png",
                                 "04 tclb_21.png", "05 tsld_1.png"])
        self.assertTrue((folder / dl.CARD_BACK_NAME).exists())
        # The second Spider printing was not downloaded at all.
        self.assertFalse(any("tdsk" in u for u in self.fake.image_calls))

    def test_token_manifest_and_sheet_csv(self):
        self.run_script("--mode", "sheets", "--tokens", "--assemble", "--tile-width", "15")
        tokens = [r for r in self.manifest_rows() if r["kind"] == "token"]
        self.assertEqual(len(tokens), 5)
        by_name = {r["name"]: r for r in tokens}
        self.assertEqual(by_name["Spider"]["created_by"], "Rotwidow Pack; Grasping Longneck")
        self.assertEqual(by_name["Treasure"]["created_by"], "Ruby, Daring Tracker")
        self.assertEqual(by_name["Spider"]["scryfall_id"], "tok-spider-a")
        self.assertTrue(all(r["kind"] == "card" and r["created_by"] == ""
                            for r in self.manifest_rows() if r["kind"] != "token"))
        sheet = self.read_sheet_csv("Sheet_tokens_1.csv")
        self.assertEqual([r["name"] for r in sheet],
                         ["Treasure", "Spider", "Urza, Planeswalker", "Undercity",
                          "Phyrexian Arena Emblem", "Card back"])
        self.assertEqual(sheet[1]["kind"], "token")
        index = self.read_index()
        self.assertEqual(index["Sheet_tokens_1.png"]["cards"], "5")
        # Card sheets are unchanged by adding tokens.
        self.assertEqual(index["Sheet_fronts_3.png"]["cards"], "42")

    def test_tokens_off_by_default(self):
        self.run_script("--mode", "sheets")
        self.assertFalse((self.out / "Sheet_tokens_1").exists())
        self.assertFalse(any("id" in i for b in self.fake.collection_calls for i in b))

    def test_tokens_in_colour_mode_go_to_tokens_folder(self):
        self.assertEqual(self.run_script("--tokens"), 0)
        self.assertEqual(sorted(p.name for p in (self.out / "Tokens").glob("*.png")),
                         ["bro_238a.png", "tclb_21.png", "tmh1_8.png", "tsld_1.png", "twoe_19.png"])
        self.assertEqual(len(list(self.out.rglob("*.png"))), 185)

    def test_missing_token_is_reported_not_fatal(self):
        del self.fake.tokens["tok-treasure"]
        self.assertEqual(self.run_script("--mode", "sheets", "--tokens"), 0)
        self.assertEqual(len(dl.sheet_slots(self.out / "Sheet_tokens_1")), 4)


class TestCopies(DownloaderTestCase):

    def setUp(self):
        super().setUp()
        # Copy of the CSV with a copies column: row 1 x3, row 3 x2, everything else blank.
        self.csv = self.tmp / "copies.csv"
        with open(DATA_CSV, newline="", encoding="utf-8-sig") as src, \
                open(self.csv, "w", newline="", encoding="utf-8") as dst:
            reader = csv.DictReader(src)
            writer = csv.DictWriter(dst, fieldnames=reader.fieldnames + ["copies"])
            writer.writeheader()
            for i, row in enumerate(reader, start=1):
                row["copies"] = {1: "3", 3: "2"}.get(i, "")
                writer.writerow(row)

    def run_copies(self, *extra):
        with mock.patch("sys.stdout"):
            return dl.main([str(self.csv), "--out", str(self.out), "--delay", "0", *extra])

    def test_copies_take_multiple_slots(self):
        self.assertEqual(self.run_copies("--mode", "sheets"), 0)
        names = [p.name for _, p in dl.sheet_slots(self.out / "Sheet_fronts_1")]
        self.assertEqual(names[:6], ["01 inr_186.png", "02 inr_186.png", "03 inr_186.png",
                                     "04 fdn_227.png", "05 dmr_151.png", "06 dmr_151.png"])
        # 180 cards + 3 extra slots = 183 -> 69 + 69 + 45
        counts = [len(dl.sheet_slots(self.out / f"Sheet_fronts_{n}")) for n in (1, 2, 3)]
        self.assertEqual(counts, [69, 69, 45])

    def test_extra_copies_are_not_downloaded_again(self):
        self.run_copies("--mode", "sheets")
        url = self.fake.image_url("inr", "186")
        self.assertEqual(self.fake.image_calls.count(url), 1)
        a = (self.out / "Sheet_fronts_1" / "01 inr_186.png").read_bytes()
        b = (self.out / "Sheet_fronts_1" / "03 inr_186.png").read_bytes()
        self.assertEqual(a, b)
        rows = [r for r in self.manifest_rows() if r["name"] == "Ambush Viper"]
        self.assertEqual(len(rows), 3)
        self.assertEqual(len({r["sha256"] for r in rows}), 1)

    def test_copies_ignored_in_colour_mode(self):
        self.assertEqual(self.run_copies(), 0)
        self.assertEqual(len(list(self.out.rglob("*.png"))), 180)

    def test_copies_resume(self):
        self.run_copies("--mode", "sheets")
        before = sorted(p.name for p in self.out.rglob("*.png"))
        calls = len(self.fake.image_calls)
        self.run_copies("--mode", "sheets")
        self.assertEqual(sorted(p.name for p in self.out.rglob("*.png")), before)
        self.assertEqual(len(self.fake.image_calls), calls)


# --- Error handling ------------------------------------------------------------

class TestErrors(DownloaderTestCase):

    def test_card_not_on_scryfall_is_reported(self):
        self.fake.missing.add(("sld", "2289"))                       # Lightning Bolt (SLD)
        self.assertEqual(self.run_script(), 1)
        self.assertEqual(len(list(self.out.rglob("*.png"))), 179)
        self.assertFalse((self.out / "R" / "sld_2289.png").exists())
        self.assertEqual(len(self.manifest_rows()), 179)

    def test_rate_limit_is_retried(self):
        url = self.fake.image_url("fdn", "227")                       # Llanowar Elves
        self.fake.rate_limit_once.add(url)
        self.assertEqual(self.run_script(), 0)
        self.assertEqual(self.fake.image_calls.count(url), 2)
        self.assertTrue((self.out / "G" / "fdn_227.png").exists())

    def test_persistent_server_error_gives_up_cleanly(self):
        url = self.fake.image_url("fdn", "227")
        self.fake.fail_always.add(url)
        self.assertEqual(self.run_script(), 1)
        self.assertEqual(self.fake.image_calls.count(url), dl.MAX_RETRIES)
        self.assertFalse((self.out / "G" / "fdn_227.png").exists())
        self.assertFalse(list(self.out.rglob("*.part")))
        self.assertEqual(len(list(self.out.rglob("*.png"))), 179)

    def test_interrupted_download_leaves_no_partial_file(self):
        class Broken(FakeResponse):
            def iter_content(self, size):
                yield PNG_MAGIC
                raise requests.ConnectionError("connection reset")

        original = self.fake.request
        target = self.fake.image_url("dmr", "151")                    # Birds of Paradise

        def flaky(method, url, **kw):
            if url == target:
                return Broken(200, b"")
            return original(method, url, **kw)

        self.fake.request = flaky
        self.assertEqual(self.run_script(), 1)
        self.assertFalse((self.out / "G" / "dmr_151.png").exists())
        self.assertFalse(list(self.out.rglob("*.part")))

    def test_missing_csv_exits(self):
        with mock.patch("sys.stdout"):
            with self.assertRaises(SystemExit):
                dl.main([str(self.tmp / "nope.csv"), "--out", str(self.out)])

    def test_scryfall_unreachable_exits(self):
        self.fake.request = lambda m, u, **kw: (_ for _ in ()).throw(requests.ConnectionError("down"))
        with mock.patch("sys.stdout"):
            with self.assertRaises(SystemExit):
                dl.main([str(DATA_CSV), "--out", str(self.out), "--delay", "0"])
        self.assertFalse(list(self.out.rglob("*.png")))


# --- Optional live smoke test --------------------------------------------------

@unittest.skipUnless(os.environ.get("SCRYFALL_LIVE"), "set SCRYFALL_LIVE=1 to hit the real API")
class TestLive(unittest.TestCase):
    """Downloads the first 5 cards of the CSV from the real Scryfall API."""

    def test_first_five_cards(self):
        tmp = Path(tempfile.mkdtemp(prefix="scryfall-live-"))
        self.addCleanup(shutil.rmtree, tmp, True)
        small = tmp / "small.csv"
        with open(DATA_CSV, encoding="utf-8-sig") as src, open(small, "w", encoding="utf-8") as dst:
            for i, line in enumerate(src):
                if i <= 5:
                    dst.write(line)
        rc = dl.main([str(small), "--out", str(tmp / "out")])
        self.assertEqual(rc, 0)
        files = list((tmp / "out").rglob("*.png"))
        self.assertEqual(len(files), 5)
        for f in files:
            self.assertEqual(f.read_bytes()[:8], PNG_MAGIC, f"{f} is not a PNG")
        with open(tmp / "out" / "manifest.csv", newline="") as f:
            names = {r["name"] for r in csv.DictReader(f)}
        self.assertEqual(names, {"Ambush Viper", "Llanowar Elves", "Birds of Paradise",
                                 "Giant Growth", "Bonesplitter"})

    def test_tokens(self):
        # Rotwidow Pack (mh1 212) creates Spider tokens.
        tmp = Path(tempfile.mkdtemp(prefix="scryfall-live-tok-"))
        self.addCleanup(shutil.rmtree, tmp, True)
        small = tmp / "tok.csv"
        with open(small, "w", newline="", encoding="utf-8") as f:
            f.write("name,Set,Collector Number\n")
            f.write("Rotwidow Pack,mh1,212\n")
        rc = dl.main([str(small), "--out", str(tmp / "out"), "--mode", "sheets", "--tokens"])
        self.assertEqual(rc, 0)
        tokens = dl.sheet_slots(tmp / "out" / "Sheet_tokens_1")
        self.assertEqual(len(tokens), 1)
        with open(tmp / "out" / "manifest.csv", newline="") as f:
            rows = [r for r in csv.DictReader(f) if r["kind"] == "token"]
        self.assertEqual(rows[0]["name"], "Spider")
        self.assertEqual(rows[0]["created_by"], "Rotwidow Pack")

    def test_double_faced_card(self):
        # Okiba Reckoner Raid // Nezumi Road Captain (neo 117) is a transform DFC.
        tmp = Path(tempfile.mkdtemp(prefix="scryfall-live-dfc-"))
        self.addCleanup(shutil.rmtree, tmp, True)
        small = tmp / "dfc.csv"
        with open(small, "w", newline="", encoding="utf-8") as f:
            f.write("name,Set,Collector Number,Color,Rarity\n")
            f.write("Okiba Reckoner Raid // Nezumi Road Captain,neo,117,B,common\n")
        rc = dl.main([str(small), "--out", str(tmp / "out"), "--mode", "sheets", "--assemble"])
        self.assertEqual(rc, 0)
        self.assertTrue((tmp / "out" / "Sheet_fronts_1" / "01 neo_117.png").exists())
        self.assertTrue((tmp / "out" / "Sheet_backs_1" / "01 neo_117_back.png").exists())
        for name in ("Sheet_fronts_1.png", "Sheet_backs_1.png", "sheets.csv"):
            self.assertTrue((tmp / "out" / "cardsheets" / name).exists(), name)
        with open(tmp / "out" / "manifest.csv", newline="") as f:
            faces = sorted(r["face"] for r in csv.DictReader(f))
        self.assertEqual(faces, ["back", "front"])


if __name__ == "__main__":
    unittest.main()
